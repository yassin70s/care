from main.view import *
from . import models,admin

class ViewSite(ViewSite):
    site_menu = [
        {
            "name":"الدخول",
            "children":[
                {
                    "name":"حالة جديدة",
                    "url":"/admin/app/newentry",
                },
                {
                    "name":"عودة سابقة",
                    "url":"/admin/app/backentry",
                },
                {
                    "name":"تحويل",
                    "url":"/admin/app/turnentry",
                },

                {
                    "name":"العمليات",
                    "url":"/admin/app/opera",
                },
            ]
        },
        
       
        {
            "name":"المتابعة",
            "children":[
                {
                    "name":"الإجراءات",
                    "url":"/admin/app/entryprocedure",
                },
                {
                    "name":"الملفات الطبية",
                    "url":"/admin/app/profilemedical",
                },
            ]
        },
        {
            "name":"المالية",
            "children":[
                {
                    "name":"الوارد",
                    "url":"/admin/app/ward",
                },
                {
                    "name":"الصرف",
                    "url":"/admin/app/order",
                },
                {
                    "name":"الصناديق",
                    "url":"/admin/app/box",
                },
                {
                    "name":"الجهات",
                    "url":"/admin/app/side",
                },
                {
                    "name":"أنواع السندات",
                    "url":"/admin/app/supporttype",
                },
            ]
        },

        {
            "name":"التقارير",
            "children":[
                {
                    "name":"الحالات الواردة",
                    "url":"/admin/app/entryr",
                },
                
                {
                    "name":"الإجراءات للمشرفين",
                    "url":"/admin/app/profilemedicalr",
                },
                {
                    "name":"الاحصاء اليومي",
                    "url":"/admin/app/facilitydiagnosir",
                },
                {
                    "name":"العمليات",
                    "url":"/admin/app/operar",
                },

                {
                    "name":"السندات الواردة",
                    "url":"/admin/app/wardr",
                },

                {
                    "name":"سندات الصرف",
                    "url":"/admin/app/orderr",
                },

                {
                    "name":"حركة الجهات",
                    "url":"/admin/app/sider",
                },
            ]

        },

        {
            "name":"الإعدادات",
            "children":[
                {
                    "name":"أنواع المرافق الطبية",
                    "url":"/admin/app/facilitytype",
                },
                {
                    "name":"المرافق الطبية",
                    "url":"/admin/app/facility",
                },
                {
                    "name":"المحاور",
                    "url":"/admin/app/axi",
                },
                {
                    "name":"الوحدات العسكرية",
                    "url":"/admin/app/unit",
                },
                {
                    "name":"المشرفين العام",
                    "url":"/admin/app/supervisorgeneral",
                },
                {
                    "name":"المشرفين المباشرين",
                    "url":"/admin/app/supervisordirect",
                },
                {
                    "name":"المحافظات",
                    "url":"/admin/app/province",
                },
                {
                    "name":"المديريات",
                    "url":"/admin/app/directorate",
                },
                {
                    "name":"المناطق",
                    "url":"/admin/app/area",
                },
                {
                    "name":"فئات الإجراءات الطبية",
                    "url":"/admin/app/procedurecategore",
                },
                {
                    "name":"الإجراءت الطبية",
                    "url":"/admin/app/procedure",
                },
                {
                    "name":"فئات أسباب الإصابات",
                    "url":"/admin/app/diagnosibecausecategore",
                },
                {
                    "name":"أسباب الإصابات",
                    "url":"/admin/app/diagnosibecause",
                },
                {
                    "name":"فئات الإصابات",
                    "url":"/admin/app/diagnosicategore",
                },
                {
                    "name":"الإصابات",
                    "url":"/admin/app/diagnosi",
                },
                {
                    "name":"فئات الأصناف",
                    "url":"/admin/app/itemcategore",
                },
                {
                    "name":"وحدات الأصناف",
                    "url":"/admin/app/itemunit",
                },
                {
                    "name":"الأصناف",
                    "url":"/admin/app/item",
                },
                {
                    "name":"الكادر الطبي",
                    "url":"/admin/app/cadre",
                },
                {
                    "name":"الوحدات العسكرية",
                    "url":"/admin/app/unit",
                },
                {
                    "name":"فئات أسباب التحويل",
                    "url":"/admin/app/turnbecausecategore",
                },
                {
                    "name":"أسباب التحويل",
                    "url":"/admin/app/turnbecause",
                },
                {
                    "name":"فئة أسباب الرقود",
                    "url":"/admin/app/backbecausecategore",
                },
                {
                    "name":"أسباب الرقود",
                    "url":"/admin/app/backbecause",
                },
                {
                    "name":"فئات أسباب الوفاة",
                    "url":"/admin/app/deathbecausecategore",
                },
                {
                    "name":"أسباب الوفاة",
                    "url":"/admin/app/deathbecause",
                },
            ]
        },
        

    ]
site = ViewSite(name="view")

