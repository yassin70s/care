from django.db import models
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.translation import gettext as _
from . import models as _models





class FacilityType(models.Model):
    name = models.CharField(_("نوع المرفق"), max_length=50,unique=True)
    class Meta:
        verbose_name = _("FacilityType")
        verbose_name_plural = _("FacilityTypes")

    def __str__(self):
        return self.name


class Axi(models.Model):
    name = models.CharField(("اسم المحور"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'محور'
        verbose_name_plural = 'المحاور'

class Facility(models.Model):
    facility_type = models.ForeignKey(FacilityType, verbose_name=_("نوع المرفق"), on_delete=models.CASCADE)
    name = models.CharField(_("اسم المرفق"), max_length=50,unique=True)
    axi = models.ForeignKey(Axi, verbose_name=_("المحور"), on_delete=models.CASCADE,null=True,blank=True)

    class Meta:
        verbose_name = _("Facility")
        verbose_name_plural = _("Facilitys")

    def __str__(self):
        return self.name

class Cadre(models.Model):
    name = models.CharField(_("name"), max_length=50)
    
    class Meta:
        verbose_name = _("Cadre")
        verbose_name_plural = _("Cadres")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("Cadre_detail", kwargs={"pk": self.pk})

class Department(models.Model):
    name = models.CharField(_("اسم القسم"), max_length=50)

    class Meta:
        verbose_name = _("Department")
        verbose_name_plural = _("Departments")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("Department_detail", kwargs={"pk": self.pk})











class Unit(models.Model):
    name = models.CharField(("اسم الوحدة"), max_length=50,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'وحدة'
        verbose_name_plural = 'الوحدات'
class SupervisorGeneral(models.Model):
    name = models.CharField(("اسم المشرف العام"), max_length=50,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'مشرف عام'
        verbose_name_plural = 'المشرفين العام'
    date_gte = None
    date_lte = None
    @property
    def profilemedicals(self):
        return ProfileMedical.objects.filter(supervisorgeneral=self)
    
    
    def data_report(self,date_gte,date_lte):
        
        _profilemedicals = []
        for profilemedical in self.profilemedicals:
            profilemedical_entrys = profilemedical.entrys.filter(date__gte=date_gte,date__lte=date_lte)
            if profilemedical_entrys.count() > 0:
                _pro_ent = []
                for entry in profilemedical_entrys:
                    _pro_ent += [{
                        "date":entry.date,
                    }]
                _profilemedicals += [{
                    "obj":profilemedical,
                    "count_entrys":profilemedical_entrys.count(),
                    "entrys":_pro_ent,
                }]

        data = {        
            "name":self.name,
            "profilemedicals":_profilemedicals,
        }
        print(data)
        return data
   
    
class SupervisorDirect(models.Model):
    name = models.CharField(("اسم المشرف المباشر"), max_length=50,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'مشرف مباشر'
        verbose_name_plural = 'المشرفين المباشرين'

    @property
    def profilemedicals(self):
        return ProfileMedical.objects.filter(supervisordirect=self)
    
class Province(models.Model):
    name = models.CharField(("اسم المحافظة"), max_length=150,unique=True)
    def __str__(self):
        return self.name

    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'محافظة'
        verbose_name_plural = 'المحافظات'
class Directorate(models.Model):
    province = models.ForeignKey(Province, verbose_name=("المحافظة"), on_delete=models.CASCADE)
    name = models.CharField(("اسم المديرية"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'مديرية'
        verbose_name_plural = 'المديريات'
class Area(models.Model):
    directorate = models.ForeignKey(Directorate, verbose_name=("المديرية"), on_delete=models.CASCADE)
    name = models.CharField(("اسم المنطقة"), max_length=150,unique=True)
    def __str__(self):
        return self.name

    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'منطقة'
        verbose_name_plural = 'المناطق'

 
    
class ProcedureCategore(models.Model):
    name = models.CharField(("اسم الفئة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'فئة إجراء طبي'
        verbose_name_plural = 'فئات الإجرات الطبية'
class Procedure(models.Model):
    procedurecategore = models.ForeignKey(ProcedureCategore, verbose_name=("فئة الإجراء الطبي"), on_delete=models.CASCADE)
    name = models.CharField(("اسم الإجراء"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'إجراء طبي'
        verbose_name_plural = 'إجراءات طبية'
class DiagnosiBecauseCategore(models.Model):
    name = models.CharField(("اسم الفئة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'فئة أسباب الإصابات'
        verbose_name_plural = 'فئات أسباب الإصابات'
class DiagnosiBecause(models.Model):
    diagnosibecausecategore = models.ForeignKey(DiagnosiBecauseCategore, verbose_name=("فئة السبب"), on_delete=models.CASCADE)
    name = models.CharField(("اسم سبب الإصابة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'سبب الإصابة'
        verbose_name_plural = 'أسباب الإصابات'




class TurnBecauseCategore(models.Model):
    name = models.CharField(("اسم الفئة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'فئة أسباب التحويل'
        verbose_name_plural = 'فئات أسباب التحويل'
class TurnBecause(models.Model):
    turnbecausecategore = models.ForeignKey(TurnBecauseCategore, verbose_name=("فئة السبب"), on_delete=models.CASCADE)
    name = models.CharField(("سبب التحويل"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'سبب التحويل'
        verbose_name_plural = 'أسباب التحويل'

class BackBecauseCategore(models.Model):
    name = models.CharField(("اسم الفئة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'فئة أسباب الرقود'
        verbose_name_plural = 'فئات أسباب الرقود'
class BackBecause(models.Model):
    backbecausecategore = models.ForeignKey(BackBecauseCategore, verbose_name=("فئة السبب"), on_delete=models.CASCADE)
    name = models.CharField(("سبب العودة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'سبب عودة'
        verbose_name_plural = 'أسباب العودات'


class DeathBecauseCategore(models.Model):
    name = models.CharField(("اسم الفئة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'فئة أسباب الوفاة'
        verbose_name_plural = 'فئات أسباب الوفاة'
class DeathBecause(models.Model):
    deathbecausecategore = models.ForeignKey(DeathBecauseCategore, verbose_name=("فئة السبب"), on_delete=models.CASCADE)
    name = models.CharField(("سبب الوفاة"), max_length=150,unique=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'سبب وفاة'
        verbose_name_plural = 'أسباب الوفاة'








class DiagnosiCategore(models.Model):
    name = models.CharField(_("فئة التشخيص"), max_length=50,unique=True)

    class Meta:
        verbose_name = _("فئة تشخيص")
        verbose_name_plural = _("فئات التشخيص")

    def __str__(self):
        return self.name


class Diagnosi(models.Model):
    diagnosiCategore = models.ForeignKey(DiagnosiCategore, verbose_name=_("فئة التشخيص"), on_delete=models.CASCADE)
    name = models.CharField(_("اسم التشخيص"), max_length=50,unique=True)

    class Meta:
        verbose_name = _("تشخيص")
        verbose_name_plural = _("التشخيصات")

    def __str__(self):
        return self.name



class ItemCategore(models.Model):
    name = models.CharField(_("اسم الفئة"), max_length=50,unique=True)

    class Meta:
        verbose_name = _("فئة صنف")
        verbose_name_plural = _("فئات الأصناف")

    def __str__(self):
        return self.name

class ItemUnit(models.Model):
    name = models.CharField(_("اسم الوحدة"), max_length=50,unique=True)
    
    class Meta:
        verbose_name = _("وحدة صنف")
        verbose_name_plural = _("وحدات الأصناف")
    is_setting = True
    def __str__(self):
        return self.name
  

class Item(models.Model):
    itemcategore = models.ForeignKey(ItemCategore, verbose_name=_("فئة الصنف"), on_delete=models.CASCADE)
    name = models.CharField(_("اسم الصنف"), max_length=50,unique=True)
    itemunit = models.ForeignKey(ItemUnit, verbose_name=_("وحدة الصنف"), on_delete=models.CASCADE)

    class Meta:
        verbose_name = _("صنف")
        verbose_name_plural = _("الأصناف")
    def __str__(self):
        return f"{self.name}"



class ProfileMedical(models.Model):
    name = models.CharField(("الاسم الرباعي مع اللقب"), max_length=150,unique=True)
    name_2 = models.CharField(("الكنية"), max_length=150)
    date_birth = models.DateField(("تاريخ الميلاد"), auto_now=False, auto_now_add=False,null=True,blank=True)
    age = models.PositiveSmallIntegerField(_("العمر"),null=True,blank=True)
    number_military = models.BigIntegerField(("الرقم العسكري"),unique=True,null=True,blank=True)
    province = models.ForeignKey(Province, verbose_name=("المحافظة"), on_delete=models.CASCADE,null=True,blank=True)
    directorate = models.ForeignKey(Directorate, verbose_name=("المديرية"), on_delete=models.CASCADE,null=True,blank=True)
    area = models.ForeignKey(Area, verbose_name=("المنطقة"), on_delete=models.CASCADE,null=True,blank=True)

    supervisorgeneral = models.ForeignKey(SupervisorGeneral, verbose_name=("المشرف العام"), on_delete=models.CASCADE)
    supervisordirect = models.ForeignKey(SupervisorDirect, verbose_name=("المشرف المباشر"), on_delete=models.CASCADE)
    phone = models.BigIntegerField(("رقم الهااتف"),null=True,blank=True)
    axi =  models.ForeignKey(Axi, verbose_name=("المحور"), on_delete=models.CASCADE,null=True,blank=True)
    unit =  models.ForeignKey(Unit, verbose_name=("مكان المرابطة"), on_delete=models.CASCADE,null=True,blank=True)

    class Meta:
        verbose_name = _("ملف طبي")
        verbose_name_plural = _("الملفات الطبية")

    def __str__(self):
        return self.name
    
    @property
    def entrys(self):
        return Entry.objects.filter(profilemedical=self)
    @property
    @admin.display(description="حالة الفرد")
    def statu(self):
        return ""
    @property
    @admin.display(description="إجمالي الإصابات")
    def total_iagnosis(self):
        return ""
    @property
    @admin.display(description="إجمالي الزيارات")
    def total_entry(self):
        return ""
    @property
    @admin.display(description="الإجراءات الطبية")
    def _entrys(self):
        return ""
    @property
    @admin.display(description="النتيجة")
    def result(self):
        return ""
    


class Opera(models.Model):
    profilemedical = models.ForeignKey(ProfileMedical, verbose_name=_("الأســـــم"), on_delete=models.CASCADE)
    facility = models.ForeignKey(Facility, verbose_name=("المستشفى"), on_delete=models.CASCADE)

    diagnosi = models.ForeignKey(Diagnosi, verbose_name=_("الاصابة"), on_delete=models.CASCADE)
    date_diagnosi = models.DateField(_("تاريخ الإصابة"), auto_now=False, auto_now_add=False)
    date = models.DateField(_("تاريخ البلاغ"), auto_now=False, auto_now_add=False)
    result = models.TextField(_("النتيجة"))

    class Meta:
        verbose_name = _("عملية")
        verbose_name_plural = _("العمليات")

    def __str__(self):
        return self.profilemedical.name
    @property
    @admin.display(description="الكنية")
    def profilemedical_name_2(self):
        return self.profilemedical.name_2
    @property
    @admin.display(description="المشرف المباشر")
    def profilemedical_supervisordirect(self):
        return self.profilemedical.supervisordirect
    @property
    @admin.display(description="مكان المرابطة")
    def profilemedical_unit(self):
        return self.profilemedical.unit

    


class Entry(models.Model):
    profilemedical = models.ForeignKey(ProfileMedical, verbose_name=_("الأســـــم"), on_delete=models.CASCADE)
    facility = models.ForeignKey(Facility, verbose_name=("المرفق الطبي"), on_delete=models.CASCADE)
    date = models.DateField(("تاريخ الدخول"), auto_now=False, auto_now_add=False)
    time = models.TimeField(_("وقت الدخول"), auto_now=False, auto_now_add=False)
    _entry_type = models.CharField(_("نوع الدخول"), max_length=50,choices=[
        ("NewEntry","حالة جديدة"),
        ("TurnEntry","تحويل"),
        ("BackEntry","عودة سابقة"),
    ])
    class Meta:
        constraints = [
            #models.UniqueConstraint(fields=["profilemedical","facility","date"],name="unique_profilemedical_facility_date")
        ]
        verbose_name = _("دخول")
        verbose_name_plural = _("حالات الدخول")
    def __str__(self):
        return f"{self.profilemedical.name} | {self.date} | {self.facility}"

    def save(self,*args, **kwargs):
        self._entry_type = self._meta.object_name
        super().save(*args, **kwargs)
    
    @property
    @admin.display(description="التاريخ")
    def date_time(self):
        return f"{self.time} | {self.date}"

    @property
    def entry_procedures(self):
        return EntryProcedure.objects.filter(entry=self)
    
    @property
    def entry_diagnosis(self):
        return EntryDiagnosi.objects.filter(entry=self)
    @property
    @admin.display(description="التشخيص")
    def entry_diagnosis_html(self):
        dis = ""
        for di in self.entry_diagnosis:
            dis += f"<div class='row'> - {di.diagnosi.name}</div>"
        return format_html(dis)
    @property
    def entry_items(self):
        return EntryItem.objects.filter(entry=self)
    
    @property
    def entry_bigg(self):
        bigg = Bigg.objects.filter(entry=self)
        if bigg.exists():
            return bigg.get(entry=self)
        return None
    @property
    def entry_result(self):
        _entry_result = EntryResult.objects.filter(entry=self)
        if _entry_result.exists():
            return _entry_result.get(entry=self)
        return None
    
    @property
    @admin.display(description="النتيجة")
    def entry_result_verbose_name(self):
        if self.entry_result:
            return getattr(_models,self.entry_result.result_type)._meta.verbose_name
        return "في الأنتظار"
        

    

    @property
    def entry_class(self):
        return getattr(_models,self._entry_type)
    @property
    def entry_object(self):
        return self.entry_class.objects.get(id=self.pk)
    
    @property
    @admin.display(description="نوع الدخول")
    def entry_type_verbose_name(self):
        return self.entry_class._meta.verbose_name
    
    @property
    @admin.display(description="رقم البلاغ")
    def number_opera(self):
        if hasattr(self.entry_object,"number_opera"):
            return self.entry_object.number_opera
        else:
            return None
    @property
    @admin.display(description="الرقم الطبي")
    def number_medical(self):
        return self.profilemedical.pk
    


class EntryDiagnosiCategore(models.Model):
    entry = models.ForeignKey(Entry, verbose_name=_("الدخول"), on_delete=models.CASCADE)
    diagnosicategore = models.ForeignKey(DiagnosiCategore, verbose_name=_("فئة الإصابة"), on_delete=models.CASCADE)
    cadre = models.ForeignKey(Cadre, verbose_name=_("الطبيب المختص"), on_delete=models.CASCADE)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["entry","diagnosicategore"],name="unique_entry_diagnosicategore")
        ]
        verbose_name = _("فئة الإصابة")
        verbose_name_plural = _("فئات الإصابة")


 

    
class EntryProcedure(models.Model):
    entry = models.ForeignKey(Entry, verbose_name=_("الدخول"), on_delete=models.CASCADE)
    procedure = models.ForeignKey(Procedure, verbose_name=_("الاجراء"), on_delete=models.CASCADE)
    class Statu1:
        name = "غير منجز"
    class Statu2:
        name = "منجز"
    class Statu3:
        name = "متأخر"
    class Statu4:
        name = "ملغي"
    
    statu = models.CharField(_("الحالة"), max_length=50,null=True,blank=True,choices=[
        (Statu1.__name__,Statu1.name),
        (Statu2.__name__,Statu2.name),
        (Statu3.__name__,Statu3.name),
        (Statu4.__name__,Statu4.name),
    ])

    facility = models.ForeignKey(Facility, verbose_name=("المرفق الطبي"), on_delete=models.CASCADE,null=True,blank=True)
    date = models.DateField(("التاريخ"), auto_now=False, auto_now_add=False,null=True,blank=True)
    time = models.TimeField(_("الوقت"), auto_now=False, auto_now_add=False,null=True,blank=True)
    cadre = models.ForeignKey(Cadre, verbose_name=_("المختص"), on_delete=models.CASCADE,null=True,blank=True)
    report = models.FileField(_("report"), upload_to="EntryProcedure/reports", max_length=100,null=True,blank=True)
    date_report = models.DateField(_("تاريخ التقرير"), auto_now=False, auto_now_add=False,null=True,blank=True)
    number_report = models.PositiveSmallIntegerField(_("رقم التقرير"),null=True,blank=True)


    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["entry","procedure"],name="unique_entry_procedure")
        ]
        verbose_name = _("اجراء طبي")
        verbose_name_plural = _("الإجراءات الطبية")
    def save(self,*args, **kwargs):
        if self.facility:
            self.statu = self.Statu2.__name__
        else:
            self.statu = self.Statu1.__name__
        super().save(*args, **kwargs)
    @property
    def _statu(self):
        if self.statu:
            return getattr(self,self.statu).name
        
    @property
    def entry_profilemedical(self):
        return self.entry.profilemedical
    @property
    def entry_date_time(self):
        return self.entry.date_time
    @property
    def entry_facility(self):
        return self.entry.facility
    
    

class EntryDiagnosi(models.Model):
    entry = models.ForeignKey(Entry, verbose_name=_("الدخول"), on_delete=models.CASCADE)
    diagnosi = models.ForeignKey(Diagnosi, verbose_name=_("التشخيص"), on_delete=models.CASCADE)
    diagnosibecause = models.ManyToManyField(DiagnosiBecause, verbose_name=("أسباب الإصابة"),null=True,blank=True)
    notice = models.TextField(_("ملاحظة"),null=True,blank=True)
    report = models.FileField(_("report"), upload_to="EntryDiagnosi/reports", max_length=100,null=True,blank=True)
    date_report = models.DateField(_("تاريخ التقرير"), auto_now=False, auto_now_add=False,null=True,blank=True)
    number_report = models.PositiveSmallIntegerField(_("رقم التقرير"),null=True,blank=True)
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["entry","diagnosi"],name="unique_entry_diagnosi")
        ]
        verbose_name = _("تشخيص")
        verbose_name_plural = _("التشخيص")

class EntryItem(models.Model):
    entry = models.ForeignKey(Entry, verbose_name=_("الدخول"), on_delete=models.CASCADE)
    item = models.ForeignKey(Item, verbose_name=_("الصنف"), on_delete=models.CASCADE)
    quantity = models.PositiveSmallIntegerField(_("الكمية"))

    class Meta:
        verbose_name = _("صنف")
        verbose_name_plural = _("الأصناف المصروقة")


class Bigg(models.Model):
    entry = models.OneToOneField(Entry, verbose_name=_("entry"), on_delete=models.CASCADE)
    facility = models.ForeignKey(Facility, verbose_name=("المرفق الطبي"), on_delete=models.CASCADE)
    date = models.DateField(("تاريخ الدخول"), auto_now=False, auto_now_add=False)
    time = models.TimeField(_("وقت الدخول"), auto_now=False, auto_now_add=False)
    period = models.PositiveSmallIntegerField(_("مدة الرقود"))


    class Meta:
        verbose_name = _("رقود")
        verbose_name_plural = _("الرقود")

    def __str__(self):
        return self.entry.__str__()
 
    

class NewEntry(Entry):
    number_opera = models.PositiveBigIntegerField(_("رقم البلاغ"),unique=True,null=True,blank=True)

    class Meta:
        verbose_name = _("دخول جديد")
        verbose_name_plural = _("الدخول الجديد")

class BackEntry(Entry):
    backresult = models.ForeignKey("EntryResult", verbose_name=_("العودة"), on_delete=models.CASCADE)

    class Meta:
        verbose_name = _("عودة سابقة")
        verbose_name_plural = _("العودات السابقة")

class TurnEntry(Entry):
    facility_in = models.ForeignKey(Facility, verbose_name=_("وارد من"), on_delete=models.CASCADE,related_name="TurnEntry_facility_in")
    
    class Meta:
        verbose_name = _("دخول التحويل")
        verbose_name_plural = _("الحالات امحولة")




class ResultMixin(models.Model):
    result_fields = []
    class Meta:
        abstract = True

    

class TeratmentResult(ResultMixin):

    class Meta:
        abstract = True

        verbose_name = _("معالجة")
        verbose_name_plural = _("المعالجات")




class TurnResult(ResultMixin):
    result_fields = ["facility_to"]
    class Meta:
        abstract = True
        verbose_name = _("تحويل")
        verbose_name_plural = _("التحويلات")

class BackResult(ResultMixin):
    result_fields = ["back_date","backbecause"]
    class Meta:
        abstract = True
        verbose_name = _("خروج بعودة")
        verbose_name_plural = _("العودات")

class DeathResult(ResultMixin):
    result_fields = ["deathbecause"]
    class Meta:
        abstract = True
        verbose_name = _("وفاة")
        verbose_name_plural = _("الوفاة")





class EntryResult(models.Model):
    entry = models.OneToOneField(Entry, verbose_name=_("السجل"), on_delete=models.CASCADE)
    result_type = models.CharField(_("result_type"), max_length=50,choices=[
        (TeratmentResult.__name__,TeratmentResult._meta.verbose_name),
        (TurnResult.__name__,TurnResult._meta.verbose_name),
        (BackResult.__name__,BackResult._meta.verbose_name),
        (DeathResult.__name__,DeathResult._meta.verbose_name),
    ])

    facility = models.ForeignKey(Facility, verbose_name=("المرفق الطبي"), on_delete=models.CASCADE)
    date = models.DateField(("تاريخ الخروج"), auto_now=False, auto_now_add=False)
    time = models.TimeField(_("وقت الخروج"), auto_now=False, auto_now_add=False)
    cadre = models.ForeignKey(Cadre, verbose_name=_("الطبيب"), on_delete=models.CASCADE)
    report = models.FileField(_("التقرير"), upload_to="result/reports", max_length=100,null=True,blank=True)
    date_report = models.DateField(_("تاريخ التقرير"), auto_now=False, auto_now_add=False,null=True,blank=True)
    
    facility_to = models.ForeignKey(Facility, verbose_name=("جهة التحويل"), on_delete=models.CASCADE,null=True,blank=True,related_name="TEntryResult_facility_to")
    turnbecause = models.ManyToManyField(TurnBecause, verbose_name=_("أسباب التحويل"),null=True,blank=True)

    back_date = models.DateField(_("تاريخ العودة"), auto_now=False, auto_now_add=False,null=True,blank=True)
    backbecause = models.ManyToManyField(BackBecause, verbose_name=_("أسباب العودة"),null=True,blank=True)

    deathbecause = models.ManyToManyField(DeathBecause, verbose_name=_("أسباب الوفاة"),null=True,blank=True)


    class Meta:
        verbose_name = _("نتيجة")
        verbose_name_plural = _("النتائج")

    def save(self,*args, **kwargs):
        super().save(*args, **kwargs)
    














class OperaR(Opera):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    supervisorgeneral = models.ForeignKey(SupervisorGeneral, verbose_name=_("المشرف العام"), on_delete=models.CASCADE,null=True,blank=True)
    supervisordirect = models.ForeignKey(SupervisorDirect, verbose_name=_("المشرف المباشر"), on_delete=models.CASCADE,null=True,blank=True)
    


    


##################3

class EntryR(Entry):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    supervisorgeneral = models.ForeignKey(SupervisorGeneral, verbose_name=_("المشرف العام"), on_delete=models.CASCADE,null=True,blank=True)
    supervisordirect = models.ForeignKey(SupervisorDirect, verbose_name=_("المشرف المباشر"), on_delete=models.CASCADE,null=True,blank=True)
    
    class Meta:
        verbose_name = _("EntryR")
        verbose_name_plural = _("EntryRs")


#الاجراءات
class EntryProcedureR(EntryProcedure):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    supervisorgeneral = models.ForeignKey(SupervisorGeneral, verbose_name=_("المشرف العام"), on_delete=models.CASCADE,null=True,blank=True)
    supervisordirect = models.ForeignKey(SupervisorDirect, verbose_name=_("المشرف المباشر"), on_delete=models.CASCADE,null=True,blank=True)
    
    class Meta:
        verbose_name = _("EntryProcedureR")
        verbose_name_plural = _("EntryProcedureRs")


#المشرفين العام
class SupervisorGeneralR(SupervisorGeneral):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    supervisorgeneral = models.ForeignKey(SupervisorGeneral, verbose_name=_("المشرف العام"), on_delete=models.CASCADE,related_name="SupervisorGeneralR_supervisorgeneral")
    #supervisordirect = models.ForeignKey(SupervisorDirect, verbose_name=_("المشرف المباشر"), on_delete=models.CASCADE,null=True,blank=True)
    
    class Meta:
        verbose_name = _("SupervisorGeneralR")
        verbose_name_plural = _("SupervisorGeneralRs")

class ProfileMedicalR(ProfileMedical):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    #supervisorgeneral = models.ForeignKey(SupervisorGeneral, verbose_name=_("المشرف العام"), on_delete=models.CASCADE,related_name="ProfileMedicalR_supervisorgeneral")
    #supervisordirect = models.ForeignKey(SupervisorDirect, verbose_name=_("المشرف المباشر"), on_delete=models.CASCADE,null=True,blank=True)
    
    class Meta:
        verbose_name = _("ProfileMedicalR")
        verbose_name_plural = _("ProfileMedicalRs")
    
    

class FacilityDiagnosiR(Diagnosi):
    facility = models.ForeignKey(Facility, verbose_name=_("المرفق الطبي"), on_delete=models.CASCADE)
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)    
    class Meta:
        verbose_name = _("FacilityDiagnosiR")
        verbose_name_plural = _("FacilityDiagnosiRs")
    
    
class ImportProfileMedical(models.Model):
    name = models.CharField(max_length=400,null=True,blank=True)
    name_2 = models.CharField(max_length=400,null=True,blank=True)
    date_birth = models.CharField(max_length=400,null=True,blank=True)
    age = models.CharField(max_length=400,null=True,blank=True)
    number_military = models.CharField(max_length=400,null=True,blank=True)
    province = models.CharField(max_length=400,null=True,blank=True)
    directorate = models.CharField(max_length=400,null=True,blank=True)
    area = models.CharField(max_length=400,null=True,blank=True)

    supervisorgeneral = models.CharField(max_length=400,null=True,blank=True)
    supervisordirect = models.CharField(max_length=400,null=True,blank=True)
    phone = models.CharField(max_length=400,null=True,blank=True)
    axi =  models.CharField(max_length=400,null=True,blank=True)
    unit =  models.CharField(max_length=400,null=True,blank=True)

    date_entry = models.CharField(max_length=400,null=True,blank=True)
    date_exit = models.CharField(max_length=400,null=True,blank=True)
    period = models.CharField(max_length=400,null=True,blank=True)
    diagnosi = models.CharField(max_length=700,null=True,blank=True)

    





###################################### المالية

class Side(models.Model):
    name = models.CharField(_("اسم الجهة"), max_length=50)
    

    class Meta:
        verbose_name = _("Side")
        verbose_name_plural = _("Sides")

    def __str__(self):
        return self.name

class Box(models.Model):
    name = models.CharField(_("اسم الصندوق"), max_length=50)

    

    class Meta:
        verbose_name = _("Box")
        verbose_name_plural = _("Boxs")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("Box_detail", kwargs={"pk": self.pk})

class SupportType(models.Model):
    name = models.CharField(_("نوع السند"), max_length=50)

    class Meta:
        verbose_name = _("support_type")
        verbose_name_plural = _("support_types")

    def __str__(self):
        return self.name

class Ward(models.Model):
    box = models.ForeignKey(Box, verbose_name=_("الصندوق"), on_delete=models.CASCADE)
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    side = models.ForeignKey(Side, verbose_name=_("الجهة"), on_delete=models.CASCADE)
    support_type = models.ForeignKey(SupportType, verbose_name=_("نوع السند"), on_delete=models.CASCADE)
    support_number = models.PositiveBigIntegerField(_("رقم السند"))
    support_file = models.FileField(_("السند"), upload_to=None, max_length=100)
    amount = models.PositiveIntegerField(_("المبلغ"))
    notice = models.TextField(_("ملاحظة"),null=True,blank=True)

    class Meta:
        verbose_name = _("Ward")
        verbose_name_plural = _("Ward")
    
    

class Order(models.Model):
    box = models.ForeignKey(Box, verbose_name=_("الصندوق"), on_delete=models.CASCADE)
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    side = models.ForeignKey(Side, verbose_name=_("الجهة"), on_delete=models.CASCADE)
    support_type = models.ForeignKey(SupportType, verbose_name=_("نوع السند"), on_delete=models.CASCADE)
    support_number = models.PositiveBigIntegerField(_("رقم السند"))
    support_file = models.FileField(_("السند"), upload_to=None, max_length=100)
    amount = models.PositiveIntegerField(_("المبلغ"))
    statement = models.CharField(_("البيان"), max_length=300)
    notice = models.TextField(_("ملاحظة"),null=True,blank=True)
    class Meta:
        verbose_name = _("Order")
        verbose_name_plural = _("Orders")


class WardR(Ward):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    


class OrderR(Order):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    

class SideR(Side):
    box = models.ForeignKey(Box, verbose_name=_("الصندوق"), on_delete=models.CASCADE)
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)
    

