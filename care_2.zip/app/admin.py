from django.http import HttpRequest
from main.admin import *
from . import models,utils
from import_export.admin import ImportExportModelAdmin
from django.contrib.auth import models as auth_models
from django.contrib.auth import admin as auth_admin

site.site_header = "Care"
site.site_title = "Care"
site.index_title = "الرئيسية"

#ite.register(auth_models.User,auth_admin.UserAdmin)
#site.register(auth_models.Group,auth_admin.GroupAdmin)

class ModelAdmin(ModelAdmin):
    list_per_page = 15


class ModelReport(ModelReport):
    report_logo_2 = "/static/app/logo.jpg"
    report_address_list = [
        "الجمهورية اليمنية",
        "وزارة الدفاع",
        "رئاسة هيئة الأركان العامة",
        "المنطقة العسكرية الخامسة",
        
    ]

class NoneAdmin(ModelAdmin):
    def has_module_permission(self, request):
        return False


site.register(
    model_or_iterable=[
        models.FacilityType, #models.Facility,
        models.Axi, models.Unit,
        models.SupervisorGeneral,
        models.SupervisorDirect,
        models.Province,
        models.Directorate,
        models.Area,
        models.ProcedureCategore,
        models.DiagnosiBecauseCategore,models.DiagnosiCategore,
        models.ItemCategore, models.ItemUnit, models.Item,
        models.TurnBecause,models.TurnBecauseCategore,
        models.DeathBecause,models.DeathBecauseCategore,
        models.BackBecause,models.BackBecauseCategore,


        #models.ResultBack,models.ResultDeath,models.ResultDigg,models.ResultTurn,
    ],admin_class=NoneAdmin
)

class ProfileMedicalAdmin(ModelAdmin,ImportExportModelAdmin):
    list_display = ["name","name_2","supervisorgeneral","supervisordirect"]
    fieldsets = (
        ("البيانات الشخصية", {
            "fields": (
                "name","name_2","phone","age","date_birth","province","directorate",
            ),
        }),
        ("البيانات الجهادية", {
            "fields": (
                "number_military","supervisorgeneral","supervisordirect","axi","unit",
            ),
        }),
    )
    
    search_fields = ["name"]
site.register(models.ProfileMedical,ProfileMedicalAdmin)

class FacilityAdmin(NoneAdmin):
    search_fields = ["name"]
site.register(models.Facility,FacilityAdmin)

class CadreAdmin(NoneAdmin):
    search_fields = ["name"]
site.register(models.Cadre,CadreAdmin)



class DiagnosiAdmin(NoneAdmin):
    search_fields = ["name"]
site.register(models.Diagnosi,DiagnosiAdmin)
class DiagnosiBecauseAdmin(NoneAdmin):
    search_fields = ["name"]
site.register(models.DiagnosiBecause,DiagnosiBecauseAdmin)
class ProcedureAdmin(NoneAdmin):
    search_fields = ["name"]
site.register(models.Procedure,ProcedureAdmin)

class EntryDiagnosiCategoreInline(TabularInline):
    model = models.EntryDiagnosiCategore
    extra = 0
    min_num = 1
class EntryProcedureInline(TabularInline):
    model = models.EntryProcedure
    extra = 0
    min_num = 1
    fields = ["procedure","facility","date","time","report","date_report","cadre"]
    autocomplete_fields = ["facility","cadre","procedure"]
class EntryDiagnosiInline(StackedInline):
    model = models.EntryDiagnosi
    extra = 1
    fields = ["diagnosi","diagnosibecause","notice","report","date_report","number_report"]
    autocomplete_fields = ["diagnosi"]
    filter_horizontal = ["diagnosibecause"]
class EntryResultInline(StackedInline):
    model = models.EntryResult
    extra = 1
    filter_horizontal = ["turnbecause","backbecause","deathbecause"]

class EntryItemInline(TabularInline):
    model = models.EntryItem
    extra = 1
    
class EntryAdmin(ModelAdmin):
    
    list_per_page = 50
    list_max_show_all = 500
    save_on_top = True
    list_display = ["profilemedical","entry_type_verbose_name","date_time","entry_result_verbose_name"]
    autocomplete_fields = ["profilemedical"]
    inlines = [
        EntryDiagnosiCategoreInline,
        EntryProcedureInline,
        EntryDiagnosiInline,
        EntryResultInline,
        EntryItemInline,
    ]
    exclude = ["_entry_type"]
class NewEntryAdmin(EntryAdmin):
    pass
site.register(models.NewEntry,NewEntryAdmin)

class BackEntryAdmin(EntryAdmin):
    pass
site.register(models.BackEntry,BackEntryAdmin)

class TurnEntryAdmin(NoneAdmin,EntryAdmin):
    pass
site.register(models.TurnEntry,TurnEntryAdmin)



########3
class BiggAdmin(ModelAdmin):
    pass
site.register(models.Bigg,BiggAdmin)

class EntryProcedureAdmin(ModelAdmin):
    list_display = ["id","entry_profilemedical","entry_date_time","entry_facility","procedure","_statu"]
    
    list_filter = ["statu"]
site.register(models.EntryProcedure,EntryProcedureAdmin)



###############3التقارير
class EntryReport(NoneAdmin,ModelReport,ModelAdmin):
    report_title = "تقرير الحالات الواردة خلال الفترة"
    list_display = ["number_opera","number_medical","entry_type_verbose_name","profilemedical","date_time","facility","entry_diagnosis_html","entry_result_verbose_name"]
    fields = ["date_gte","date_lte","supervisorgeneral","supervisordirect"]
    report_is_horizontal = False
    report_fieldsets = (
        (None, {
            "fields": (
                "date_gte","date_lte"
            ),
        }),
        (None, {
            "fields": (
                "supervisorgeneral","supervisordirect",
            ),
        }),
    )
    def get_queryset(self, request):
        queryset = models.Entry.objects.get_queryset()
        supervisorgeneral_id = self.data["supervisorgeneral"][0]
        supervisordirect_id = self.data["supervisordirect"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        queryset = queryset.filter(date__gte=date_gte,date__lte=date_lte)
        if supervisorgeneral_id:
            queryset = queryset.filter(profilemedical__supervisorgeneral__id=supervisorgeneral_id)
        elif supervisordirect_id:
            queryset = queryset.filter(profilemedical__supervisordirect__id=supervisordirect_id)
        
        return queryset
site.register(models.EntryR,EntryReport)





class ProfileMedicalReport(ModelReport,NoneAdmin):
    report_title = "التقرير العام للحالات خلال الفترة"
    report_is_horizontal = False
    list_display = [
        "name","name_2","supervisordirect",
        "statu","total_iagnosis","total_entry",
        "_entrys","result",
    ]
    

    fields = ["date_gte","date_lte","supervisorgeneral"]
    report_fieldsets = (
        (None, {
            "fields": (
                "date_gte","date_lte"
            ),
        }),
        (None, {
            "fields": (
                "supervisorgeneral",
            ),
        }),
    )
    
    def get_queryset(self, request):
        queryset = models.ProfileMedical.objects.get_queryset()
        supervisorgeneral_id = self.data["supervisorgeneral"][0]
        if supervisorgeneral_id:
            queryset = queryset.filter(supervisorgeneral__id=supervisorgeneral_id)
        return queryset
    def report_get_context(self, request, object_id=None, extra_context=None):
        extra_context = extra_context or {}
        supervisorgeneral = models.SupervisorGeneral.objects.get(id=self.data["supervisorgeneral"][0])
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        
        
        supervisorgeneral_entrys = models.Entry.objects.filter(profilemedical__supervisorgeneral=supervisorgeneral)
        supervisorgeneral_profilemedicals = models.ProfileMedical.objects.filter(supervisorgeneral=supervisorgeneral)
        #supervisordirects = models.SupervisorDirect.objects.filter(id__in=list(supervisorgeneral_profilemedicals.values_list("supervisordirect").distinct()))
        profilemedicals = []
        for profile in supervisorgeneral_profilemedicals:
            profile_entrys = supervisorgeneral_entrys.filter(profilemedical=profile)
            if profile_entrys.filter(date__gte=date_gte,date__lte=date_lte).count() > 0:
                procedures = models.EntryProcedure.objects.filter(entry__id__in=list(profile_entrys.filter(date__gte=date_gte,date__lte=date_lte).values_list(flat=True)))
                entry_list = []
                entry_index = 1
                procedure_index = 1
                for ent in profile_entrys.filter(date__gte=date_gte,date__lte=date_lte):
                    procedures_list = []
                    ent_entry_procedures = ent.entry_procedures
                    entry_procedure_index = 1
                    for pdu in ent_entry_procedures:
                        procedures_list += [{
                            "index":procedure_index,
                            "obj":pdu,
                            "statu":pdu._statu,
                            "entry_index":entry_index,
                            "entry_procedure_index":entry_procedure_index,

                        }]
                        entry_procedure_index += 1
                        procedure_index += 1

                    entry_list += [{
                        "rowspan":ent_entry_procedures.count(),
                        "entry_index":entry_index,
                        "obj":ent,
                        "procedures":procedures_list,

                    }]
                    entry_index += 1




                profilemedicals += [{
                    "rowspan":procedures.count(),
                    "name":profile.name,
                    "name_2":profile.name_2,
                    "supervisordirect":profile.supervisordirect,
                    "statu":profile.statu,
                    "diagnosi_count":models.EntryDiagnosi.objects.filter(entry__profilemedical=profile).count(),
                    "entrys_last_count":profile_entrys.filter(date__lt=date_gte).count(),
                    "entrys_count":profile_entrys.filter(date__gte=date_gte,date__lte=date_lte).count(),
                    "entrys":entry_list,
                }]

        entry_new = supervisorgeneral_entrys.filter(_entry_type=models.NewEntry.__name__)
        entry_back = supervisorgeneral_entrys.filter(_entry_type=models.BackEntry.__name__)
        entry_turn = supervisorgeneral_entrys.filter(_entry_type=models.TurnEntry.__name__)

        




        context = {
            "entry_first_count":supervisorgeneral_entrys.filter(date__lt=date_gte).count(),
            "entry_count":supervisorgeneral_entrys.filter(date__gte=date_gte,date__lte=date_lte).count(),
            "entry":{
                "new":{
                    "total":entry_new.filter(date__gte=date_gte,date__lte=date_lte).count(),
                    "befor":entry_new.filter(date__lt=date_gte).count(),
                },
                 "back":{
                    "total":entry_back.filter(date__gte=date_gte,date__lte=date_lte).count(),
                    "befor":entry_back.filter(date__lt=date_gte).count(),
                },
                 "turn":{
                    "total":entry_turn.filter(date__gte=date_gte,date__lte=date_lte).count(),
                    "befor":entry_turn.filter(date__lt=date_gte).count(),
                },
            },
            "result":{
                "teratment":{
                    "total":0,
                    "befor":0,
                },
                 "back":{
                    "total":0,
                    "befor":0,
                },
                 "turn":{
                    "total":0,
                    "befor":0,
                },
                 "death":{
                    "total":0,
                    "befor":0,
                },
                "no_result":{
                    "total":0,
                    "befor":0,
                },

            },
            
            
            
            "profilemedicals":profilemedicals,
        }
        extra_context.update(
            context
        )
        return super().report_get_context(request, object_id, extra_context)
site.register(models.ProfileMedicalR,ProfileMedicalReport)



class FacilityDiagnosiReport(ModelReport,NoneAdmin):
    report_is_horizontal = False
    list_display = ["name"]
    fields = ["facility","date"]
    def get_queryset(self, request):
        queryset = models.Diagnosi.objects.get_queryset()
        _ids = []
        for qs in queryset:
            if self._total(qs) > 0:
                _ids += [qs.pk]
        return queryset.filter(id__in=_ids)
    
    def _set_field_days(self,*args, **kwargs):
        day = kwargs["day"]
        date = kwargs["date"]
        facility = kwargs["facility"]
        @display(description=f"{day}")
        def _day(self):
            entry_count = models.EntryDiagnosi.objects.filter(diagnosi=self).filter(entry__facility=facility).filter(
                entry__date=datetime(
                    year=date.year,
                    month=date.month,
                    day=day,
                ).date()
            ).count()
            if entry_count > 0:
                return entry_count
            else:
                return ""
        return _day
    report_fieldsets = (
        (None, {
            "fields": (
                "facility",
            ),
        }),
        (None, {
            "fields": (
                "_month",
            ),
        }),
       
    )

    @display(description="الشهر")
    def _month(self):
        date = parse_date(str(self.data["date"][0]))
        return f"{date.year} / {date.month}"




    @display(description="الإجمالي")
    def _total(self,obj):
        facility_id = self.data["facility"][0]
        date = parse_date(str(self.data["date"][0]))
        total = models.EntryDiagnosi.objects.filter(diagnosi=obj).filter(entry__facility__id=facility_id).filter(
                entry__date__gte=datetime(
                    year=date.year,
                    month=date.month,
                    day=1,
                ).date(),
                entry__date__lte=datetime(
                    year=date.year,
                    month=date.month,
                    day=30,
                ).date(),
            ).count()
        return total
    
    
    def get_list_display(self, request):
        facility = models.Facility.objects.get(id=self.data["facility"][0])
        date = parse_date(str(self.data["date"][0]))

        list_display = ["name"]
        for day in range(1,31):
            field_name = f"_{day}"
            setattr(self,field_name,self._set_field_days(**{
                "facility":facility,
                "date":date,
                "day":day,
            }))
            list_display += [field_name]
        list_display += ["_total"]
        return list_display
    
site.register(models.FacilityDiagnosiR,FacilityDiagnosiReport)








"""class ImportProfileMedicalAdmin(ModelAdmin,ImportExportModelAdmin):
    list_display = ["name","name_2","_count"]
    def _count(self,obj):
        return models.ImportProfileMedical.objects.filter(name=obj.name).count()
site.register(models.ImportProfileMedical,ImportProfileMedicalAdmin)
"""
class OperaAdmin(NoneAdmin,ModelAdmin):
    pass
site.register(models.Opera,OperaAdmin)


###############3التقارير
class OperaReport(NoneAdmin,ModelReport,ModelAdmin):
    report_title = "تقرير البلاغات "
    list_display = ["profilemedical","profilemedical_name_2","profilemedical_supervisordirect","profilemedical_unit","facility","diagnosi","date_diagnosi","date","result"]
    fields = ["date_gte","date_lte","supervisorgeneral","supervisordirect"]
    report_is_horizontal = False
    report_fieldsets = (
        (None, {
            "fields": (
                "date_gte","date_lte"
            ),
        }),
        (None, {
            "fields": (
                "supervisorgeneral","supervisordirect",
            ),
        }),
    )
    def get_queryset(self, request):
        queryset = models.Opera.objects.get_queryset()
        supervisorgeneral_id = self.data["supervisorgeneral"][0]
        supervisordirect_id = self.data["supervisordirect"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        queryset = queryset.filter(date__gte=date_gte,date__lte=date_lte)
        if supervisorgeneral_id:
            queryset = queryset.filter(profilemedical__supervisorgeneral__id=supervisorgeneral_id)
        elif supervisordirect_id:
            queryset = queryset.filter(profilemedical__supervisordirect__id=supervisordirect_id)
        
        return queryset
site.register(models.OperaR,OperaReport)



ImportProfileMedical = models.ImportProfileMedical.objects.all()








"""


####################################### المالية
class BoxAdmin(ModelAdmin):
    list_display = ["name"]
site.register(models.Box,BoxAdmin)

class SideAdmin(ModelAdmin):
    list_display = ["name"]
site.register(models.Side,SideAdmin)

class SupportTypeAdmin(ModelAdmin):
    list_display = ["name"]
site.register(models.SupportType,SupportTypeAdmin)




class WardAdmin(ModelAdmin):
    list_display = ["box","date","side","support_type","support_number","support_file","amount"]
    
site.register(models.Ward,WardAdmin)


class OrderAdmin(ModelActionReport):
    list_display = ["box","date","side","support_type","support_number","support_file","amount","statement","notice"]
    
site.register(models.Order,OrderAdmin)


class WardReport(ModelReport,ModelAdmin):
    report_footer_list = [
        "المختص:",
        "المسؤول:",

    ]
    report_title = "الوارد إلى الصندوق خلال فترة"
    list_display = ["date","side","support_type","support_number","amount","notice"]
    fields = ["box","date_gte","date_lte"]
    report_fieldsets = (
        (None, {
            "fields": (
                "date_gte","date_lte"
            ),
        }),
        (None, {
            "fields": (
                "box","_total",
            ),
        }),
    )

    @display(description="الإجمالي")
    def _total(self):
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        queryset = models.Ward.objects.filter(date__gte=date_gte,date__lte=date_lte).filter(box__id=box_id)
        return queryset.aggregate(total=Sum("amount"))["total"]

    def get_queryset(self, request):
        queryset = models.Ward.objects.get_queryset()
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        queryset = queryset.filter(date__gte=date_gte,date__lte=date_lte).filter(box__id=box_id)
        return queryset
site.register(models.WardR,WardReport)




class OrderReport(ModelReport,ModelAdmin):
    report_footer_list = [
        "المختص:",
        "المسؤول:",

    ]
    report_title = "المصروف من الصندوق خلال فترة"
    list_display = ["date","side","support_type","support_number","amount","statement","notice"]
    fields = ["box","date_gte","date_lte"]
    report_fieldsets = (
        (None, {
            "fields": (
                "date_gte","date_lte"
            ),
        }),
        (None, {
            "fields": (
                "box","_total",
            ),
        }),
    )

    @display(description="الإجمالي")
    def _total(self):
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        queryset = models.Order.objects.filter(date__gte=date_gte,date__lte=date_lte).filter(box__id=box_id)
        return queryset.aggregate(total=Sum("amount"))["total"]
    def get_queryset(self, request):
        queryset = models.Order.objects.get_queryset()
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        queryset = queryset.filter(date__gte=date_gte,date__lte=date_lte).filter(box__id=box_id)
        return queryset
site.register(models.OrderR,OrderReport)




class SideReport(ModelReport,ModelAdmin):
    report_title = " الوارد والمصروف للجهات"
    list_display = ["name","_ward","_order"]
    fields = ["box","date_gte","date_lte"]
    report_fieldsets = (
        (None, {
            "fields": (
                "date_gte","date_lte"
            ),
        }),
        (None, {
            "fields": (
                "box","_total_amount",
            ),
        }),
        (None, {
            "fields": (
                "_ward_total","_order_total",
            ),
        }),
    )
    def get_queryset(self, request):
        queryset = models.Side.objects.get_queryset()
        
        return queryset
    @display(description="إجمالي الوارد من الجهة")
    def _ward(self,obj):
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        return models.Ward.objects.filter(
            side=obj,
            date__gte=date_gte,
            date__lte=date_lte,
            box__id=box_id,
        ).aggregate(total=Sum("amount"))["total"]
    @display(description="إجمالي المصروف للجهة")
    def _order(self,obj):
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        return models.Order.objects.filter(
            side=obj,
            date__gte=date_gte,
            date__lte=date_lte,
            box__id=box_id,
        ).aggregate(total=Sum("amount"))["total"]
    
    @display(description="المبلغ المتبقي")
    def _total_amount(self):
        box_id = self.data["box"][0]
        return models.Ward.objects.filter(
            box__id=box_id,
        ).aggregate(total=Sum("amount"))["total"] - models.Order.objects.filter(
            box__id=box_id,
        ).aggregate(total=Sum("amount"))["total"]

    @display(description="إجمالي الوارد")
    def _ward_total(self):
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        return models.Ward.objects.filter(
            date__gte=date_gte,
            date__lte=date_lte,
            box__id=box_id,
        ).aggregate(total=Sum("amount"))["total"]
    @display(description="إجمالي المصروف")
    def _order_total(self):
        box_id = self.data["box"][0]
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))
        return models.Order.objects.filter(
            date__gte=date_gte,
            date__lte=date_lte,
            box__id=box_id,
        ).aggregate(total=Sum("amount"))["total"]
    
site.register(models.SideR,SideReport)


"""